![MLD](image.png)

![MCD](image-1.png)