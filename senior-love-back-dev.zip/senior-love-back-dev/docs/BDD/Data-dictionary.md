# Dictionnaire de données:

lien google doc [Dictionnaire](https://docs.google.com/spreadsheets/d/1bpRm4KMfcluQRPSJsFIN80TpagXWnk--ten4bsaBdCI/edit?gid=0#gid=0)