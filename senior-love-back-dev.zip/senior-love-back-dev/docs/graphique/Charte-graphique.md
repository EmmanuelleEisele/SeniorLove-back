# Charte graphique et design :

- Interface claire, police lisible
- Couleurs douces et rassurantes
- Gros icônes, boutons visibles
- Accessibilité : Contraste élevé, zoom, navigation intuitive

lien vers la maquette sur [Figma](https://www.figma.com/design/d7HFWC2Nk0u54pGNRu5gLK/SeniorLove?node-id=0-1&p=f&t=1eeGoNZbWSwkkwSz-0)

## Wireframe
- [Haut](Wireframe1.png) de la page WEB accueil
- [Bas](Wireframe2.png) de la page WEB accueil

## Zoning:
- [Mobile](Zoning-Mobile-first.png)
- [Tablette](Zoning-Tablet.png)
- [Web](Zoning-Web.png)