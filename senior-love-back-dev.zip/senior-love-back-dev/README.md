# Projet SeniorLove (site de rencontre pour +60):

## Sprint 0:
Les éléments se trouvent dans [docs](docs)